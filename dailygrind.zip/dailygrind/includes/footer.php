<footer class="footer">
    <p>Copyright © The Daily Grind Coffee House</p>
    <p id="time-slot"></p>
</footer>